import React from 'react';
import {Alert, Button} from "@mui/material";

const FiveApp = () => {
    return (
        <div>
            <Alert severity='success'>FiveApp - useRef 응용</Alert>
            <table className={'table table-bordered'} style={{width:'300px'}}>
                <thead>
                    <tr>
                        <th className='table-success' width="100">이름</th>
                        <th>
                            <input type='text' className='form-control'/>
                        </th>
                    </tr>
                    <tr>
                        <th className='table-success' width="100">Java Score</th>
                        <th>
                            <input type='text' className='form-control'/>
                        </th>
                    </tr>
                    <tr>
                        <th className='table-success' width="100">React Score</th>
                        <th>
                            <input type='text' className='form-control'/>
                        </th>
                    </tr>
                <tr>
                    <td colspan={2} align='center'>
                        <Button variant='outlioned' color="warning">결과보기</Button>
                    </td>
                </tr>
                </thead>

            </table>
        </div>
    );
};

export default FiveApp;