import React from 'react';
import {Alert} from "@mui/material";

const SevenApp = () => {
    return (
        <div>
            <Alert severity='success'>SevenApp</Alert>
        </div>
    );
};

export default SevenApp;