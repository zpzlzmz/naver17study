import React from 'react';
import {Alert} from "@mui/material";

const SixApp = () => {
    return (
        <div>
            <Alert severity='success'>SixApp</Alert>
        </div>
    );
};

export default SixApp;