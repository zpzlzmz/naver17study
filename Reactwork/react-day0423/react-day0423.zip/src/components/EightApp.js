import React from 'react';
import {Alert} from "@mui/material";

const EightApp = () => {
    return (
        <div>
            <Alert severity='success'>EightApp</Alert>
        </div>
    );
};

export default EightApp;